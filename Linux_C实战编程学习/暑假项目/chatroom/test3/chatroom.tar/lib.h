#ifndef __LIB_H
#define __LIB_h

#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<sys/wait.h>

#define SERVPORT 5555
#define BUFLEN 1024
#define MAX(a,b) (((a)>(b))?(a):(b))

#endif

