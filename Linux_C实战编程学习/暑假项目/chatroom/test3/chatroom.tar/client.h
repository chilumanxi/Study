#ifndef __CLIENT_H
#define __CLIENT_H

#include"lib.h"

#define DEBUG_VERSION

#endif

